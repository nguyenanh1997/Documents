<?php
namespace Software\Workflow;
class WorkflowProcedure extends \CMS\CRUD{
    static $type = 'Decl.WorkflowProcedure';
    static $checkSite = true;
    static $options = [
        'orderBy' => 'sortOrder DESC',
        'itemsPerPage'=>20,
        'pageNo' => 1,
        'fields'=>'*',
    ];
    static $privileges  = [
        'selectList' => 'member',
        'select' => 'member',
        'selectAll' => 'owner',
        'edit' => 'owner',
        'delete' => 'owner',
    ];
    static $selectListFields = '_id,title,code,parentId,sortOrder, workflowType, workflowTypes';
    static $requiredFields = ['title', 'callService', 'functionType'];
    static $items;
	protected function prepareEdit(&$fields, &$oldItem, &$return) {
		$fields['status'] = '1';
    	return parent::prepareEdit($fields, $oldItem, $return);
    }
	protected function prepareFilters(&$filters) {
		parent::prepareFilters($filters);
		if(!empty($filters['functionType'])
			and strpos($filters['functionType'], ',') !== false
		) {
			$filters['functionType'] = [
				'$in' => array_map('trim', explode(',', $filters['functionType']))
			];
		}
    }
	protected function prepareSelectList(&$return, $options) {
		parent::prepareSelectList($return, $options);
		if(empty($return['filters']['workflowTypes'])){
			$workflowTypes = Data('CoreDecl.WorkflowType')->setKey('code')->fields('id,type, code, title')->selectAll(['site' => 10263]);
			foreach($return['items'] as $key => $item){
				if(!empty($item['workflowTypes'])){
					$workflowTypeTitle = '';
					foreach($item['workflowTypes'] as $workflowType){
						$workflowTypeTitle .= (!empty($workflowTypeTitle) ? ', ' : '').(!empty($workflowTypes[$workflowType]['title1']) ? $workflowTypes[$workflowType]['title1'] : $workflowType);
					}
					$return['items'][$key]['title'] = '('.title($workflowTypeTitle).') '.($item['title'] ?? '');
				}
			}
		}
	}
	/**
	 * Usage: Lấy trường theo $id
	 * Privileges: member
	 */
	function getSettingForm($id = '', $item = [], $objectType = '', $objectId = '', $data = []) {
		if(empty($item)
			and !empty($id)
		){
			$item = Data(static::$type)->select($id);
		}
		if(!empty($item)){
			$elements = !empty($item['parameters']) ? $item['parameters'] : [];
			if(!empty($elements)){
				foreach ($elements as $key => $element){
					$elements[$key]['sm'] = $elements[$key]['md'] = 12;
					if(empty($element['code'])){
						unset($elements[$key]);
					}elseif (!empty($element['settings'])){
						$settings = is_string($element['settings']) ? json_decode($element['settings'], 1) : [];
						if (!empty($settings['hasComponent'])){
							$check = 0;
							$components = explode(',', $settings['hasComponent']);
							foreach ($components as $component){
								if (hasComponent($component)){
									$check = 1;
									break;
								}
							}
							if (!$check){
								unset($elements[$key]);
							}
						}
					}
				}
				$data = !empty($data) ? $data : [];
				if(empty($data)
					and !empty($objectType)
					and !empty($objectId)
				){
					$data = Data($objectType)->select($objectId);
				}
				if(is_string($data)){
					$data = json_decode($data, 1);
				}
				$settingForm = call('Content.CustomForm.parse', [
					'elements' => $elements,
					'mid' => request('moduleId'),
					'options' => ['wrapper' => 'columns'],
					'data' => $data
				]);
				return $settingForm;
			}
		}
		return '';
	}
	/**
	 * User: hungnm
	 * Usage:
	 * Privileges:member
	 */
	function getTitle($id = '', $code = '', $field = '') {
		$return = '';
		$field = !empty($field) ? $field : 'title';
		$code = !empty($code) ? $code : 'id';
		if(static::$items === null) {
			static::$items = Data(static::$type)->itemsPerPage(10000)->selectAll(['site' => intval(portal()->id)]);
			foreach(static::$items as $item) {
				if(!empty($item[$code])
					and !isset(static::$items[$item[$code]])
				) {
					static::$items[$item[$code]] = $item;
				}
			}
		}
		if(!empty($id)) {
			$ids = is_array($id) ? $id : array_map('trim', explode(',', $id));
			foreach($ids as $id) {
				if(!empty(static::$items)
					and !empty(static::$items[$id])
					and isset(static::$items[$id][$field])
				) {
					$return .= static::$items[$id][$field].', ';
				}
			}
			$return = substr($return, 0, strrpos($return, ','));
		}
		return $return;
	}
}