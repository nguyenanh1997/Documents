<?php

namespace Software;
class PersonalTask extends \CMS\CRUD
{
    static $type = 'PersonalTask';
    static $options = [
        'itemsPerPage' => 20,
        'fields' => '*',
        'orderBy' => 'sortOrder DESC'
    ];
    static $privileges = [
        'select' => 'Software.PersonalTask.view',
        'selectAll' => 'member',
        'delete' => 'Software.PersonalTask.delete',
        'edit' => 'Software.PersonalTask.add',
        'selectList' => 'member',
    ];
    static $simpleQueries = [
        [
            'site' => 'int',
            'type2' => 'string',
            'assigns' => 'string',
        ]
    ];

    protected function prepareFilters(&$filters)
    {
        parent::prepareFilters($filters);
        $filters['site'] = intval(portal()->id);
        if (!hasAction('Software.PersonalTask.admin')) {
            $filters['assigns'] = [
                '$in' => user()->accountId
            ];
        }
        if (empty($filters['groupId']) && CUser::$group['type'] !== 'Group.CMS') {
            $filters['groupId'] = CUser::$group['id'];
        }
    }


    protected function prepareList(&$return)
    {
        parent::prepareList($return);
	    
        if (!empty($return['items'])) {
            foreach ($return['items'] as $key => $item) {
                if (hasAction('Software.PersonalTask.admin') or (!empty($item['creatorId']) and ($item['creatorId'] == intval(user()->id)))) {
                    $return['items'][$key]['hasEdit'] = 1;
                }
            }
        }
    }

    protected function prepareEdit(&$fields, &$oldItem, &$return)
    {
	    if(hasComponent('Software.HRM.Officer')){
	    	if(!empty($fields['status'])
		        and $fields['status']=='5b03ed86e138230d603833b2'
		    ){
	    	    $fields['endTime'] = intval(time());
		    }
	    	else{
			    $fields['endTime'] = '';
		    }
	    }
        if (!empty($fields['title'])) {
            $fields['sortTitle'] = CVNCode::convertUtf8ToSort(strip_tags($fields['title']));
        }
        if (empty($oldItem)) {
            if (empty($fields['creatorAccountId'])) {
                $fields['creatorAccountId'] = user()->accountId;
            }
            if (empty($fields['groupId'])) {
                $fields['groupId'] = CUser::$group['id'];
            }
            if (!empty($fields['objectId']) and $customer = Data('Group')->fields('_id,customerId')->select($fields['objectId'])) {
                $fields['objectId'] = $customer['customerId'];
            }
        }
        if (!empty($fields['title'])) {
            $fields['suggestTitle'] = call('Content.Suggester.getSuggestTitle', [
                'item' => [
                    'title' => $fields['title']
                ]
            ]);
        }
        return parent::prepareEdit($fields, $oldItem, $return);
    }

    protected function checkItem(&$item)
    {
        $item['releaseItems'] = $this->getRelates($item['id'], [
            'categories' => $item['categories'] ?? ''
        ]);

        return parent::checkItem($item);
    }

    protected function checkDelete(&$item, &$return)
    {
        if (hasAction('Software.PersonalTask.admin') or (!empty($item['creatorId']) and ($item['creatorId'] == intval(user()->id)))) {
            return true;
        } else {
            return false;
        }
    }

    protected function checkEdit(&$item)
    {
        if (hasAction('Software.PersonalTask.admin') or (!empty($item['creatorId']) and ($item['creatorId'] == intval(user()->id)))) {
            return true;
        } else {
            return false;
        }
    }

    protected function editSuccess(&$return, $fields, $oldItem)
    {
        Data('Post.Activity')->insert([
            'creatorAccountId' => user()->accountId,
            'creatorTitle' => user()->fullName,
            'creatorAvatar' => user()->image,
            'privacyPolicies' => ['all'],
            'status' => '1',
            'isDisplay' => '1',
            'shareType' => 'public',
            'totalComments' => 0,
            'warningLevel' => 1,
            'linkId' => $return['id'],
            'linkType' => static::$type,
        ]);
    }

    /**
     * Usage: Lấy danh sách bài liên quan
     * Privilges: $privileges[select]
     * @param $id
     * @return array
     */
    function getRelates($id, $filters = false)
    {
        $filters = !empty($filters) ? $filters : [];
        $items = [];
        $filters['site'] = intval(portal()->id);
        $filters['projectId'] = CUser::$group['id'];
        $filters['status'] = '1';

        if (!empty($id) and $item = Data(static::$type)->fields('_id,type,createdTime,sortOrder,categories')->select($id)) {
            $filters['createdTime'] = [
                '$lte' => $item['createdTime']
            ];
            $items = Data(static::$type)->fields('_id,title')->itemsPerPage(100)->orderBy('sortOrder DESC')->selectAll($filters);
            unset($items[strval($id)]);
        }
        return $items;
    }

    /**
     * Usage: Lấy danh sách công việc của ngày hôm nay và những việc chưa hoàn thành của các ngày khác
     * Privileges: member
     */
    function taskSelectAll($filters = false, $itemsPerPage = false, $oderBy = false, $pageNo = false)
    {
        $filters = !empty($filters) ? $filters : [];
        $itemsPerPage = !empty($itemsPerPage) ? $itemsPerPage : 20;
        $oderBy = !empty($oderBy) ? $oderBy : 'dailyLogTime DESC';
        $pageNo = !empty($pageNo) ? $pageNo : 1;
        $filters['site'] = intval(portal()->id);
        
		$filters['dailyLogTime'] = ['$gt' => strtotime(date('Y-m-d', time() - 24*3600))];
        $return = [
            'items' => Data('PersonalTask')->itemsPerPage(200)->orderBy('creatorAccountId ASC')->selectAll($filters),
        ];
        foreach ($return['items'] as $i => $item) {
            $return['items'][$i]['creatorCode'] = Data('Account')->getTitle($item['creatorAccountId'], 'code');
        }
        $return['totalItems'] = sizeof($return['items']);
        uasort($return['items'], function ($a, $b) {
            return $a['creatorCode'] <=> $b['creatorCode'];
        });
        return $return;
    }

    /**
     * Privileges: owner
     */
    function report(){
        $start = strtotime(date('Y-m-01', time() - 30 * 24 * 3600));
        $end = strtotime(date('Y-m-01'));
        $items = Data('PersonalTask')->aggregate([
            ['$match' => [
                'site' => intval(portal()->id),
                'dailyLogTime' => [
                    '$gte' => $start,
                    '$lt' => $end,
                ]
            ]],
            ['$group' => [
                '_id' => [
                    'accountId' => '$creatorAccountId',
                    'day' => ['$dateToString' => [
                        'format' => '%d',
                        'date' => ['$add' => [
                            new MongoDB\BSON\UTCDateTime(7*3600000),
                            ['$multiply' => [1000, '$dailyLogTime']]
                        ]]
                    ]]
                ],
                'count' => ['$sum' => 1]
            ]]
        ]);
        $days = [];
        for($i = $start; $i < $end; $i+= 24*3600){
            $days[date('d', $i)] = [
                'day' => date('d', $i),
                'count' => '',
                'total' => 0,
            ];
        }
        $users = [];
        foreach($items as $item){
            if(empty($item['_id']['accountId'])){
                continue;
            }
            $userId = $item['_id']['accountId'];
            if(!isset($users[$userId])){
                if(!$account = Data('Account')->fields('code,fullName,email')->select($userId)){
                    continue;
                }
                $users[$userId] = $account;
                $users[$userId]['days'] = $days;
                $users[$userId]['total'] = 0;
                $users[$userId]['totalMissing'] = 0;
            }
            $users[$userId]['days'][$item['_id']['day']]['count'] = $item['count'];
            $days[$item['_id']['day']]['total']++;
            $users[$userId]['total']++;
        }
        $monthTotal = 0;
        foreach($days as $day){
            if($day['total'] > sizeof($users)/2){
                $monthTotal++;
            }
        }
        foreach($users as $i => $user){
            $users[$i]['monthTotal'] = $monthTotal;

        }
        $bonusInMonths = Data('Document.Bonus')->fields('_id,title,bonusTypeId,staffId,bonusTime,bonusFormType,value,unit')->itemsPerPage(100000)->selectAll([
            'site' => intval(portal()->id),
            'bonusTime' => [
                '$gte' => $start,
                '$lt' => $end,
            ]
        ]);
        foreach($bonusInMonths as $bonus){
            if(in_array($bonus['bonusTypeId'], ['5afa68b2e138231c385ad947', '5b1a32d7333085708228c5c4', '5bb6fb543330855d863ca4d4']) and isset($users[$bonus['staffId']])){
                $users[$bonus['staffId']]['monthTotal'] --;
                $users[$bonus['staffId']]['totalMissing'] ++;
            }
        }
        foreach($users as $i => $user){
            if($user['total'] < $user['monthTotal'] - 5){
                $users[$i]['backgroundColor'] = '#ffa6a6';
            }
            elseif($user['total'] < $user['monthTotal']){
                $users[$i]['backgroundColor'] = 'yellow';
            }
        }
        return ['items' => $users, 'totalItems' => sizeof($users), 'days' => $days, 'month' => date('m', $start)];
    }
}

?>