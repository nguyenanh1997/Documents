<?php

namespace Software;
class Report extends \CMS\CRUD
{
    static $type = 'Report';
    static $checkSite = true;
    static $options = [
        'itemsPerPage' => 20,
        'fields' => '*',
        'orderBy' => 'createdTime DESC,parentId ASC,sortOrder DESC'
    ];
    static $privileges = [
        'select' => 'Software.Report.view',
        'selectAll' => 'member',
        'delete' => 'Software.Report.delete',
        'edit' => 'Software.Report.add'
    ];
}