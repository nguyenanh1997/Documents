<?php
namespace Software;
class Rating extends \CMS\Listing {
    static $type = 'Rating';
    static $checkSite = true;
    static $options = [
        'itemsPerPage' => 20,
        'fields' => '*',
        'orderBy' => 'sortOrder DESC'
    ];
    static $privileges = [
        'select' => 'member',
        'selectAll' => 'member',
    ];

    protected function prepareFilters(&$filters){
        parent::prepareFilters($filters);
        $filters['site'] = intval(portal()->id);
    }
    protected function prepareList(&$return){
        parent::prepareList($return);
        if(!empty($return['items'])) {
            foreach ($return['items'] as $key => $item) {
                if (!empty($item['accountId']) and $account = Data('Account')->fields('_id,fullName,image,code')->select($item['accountId'])) {
                    $item['creatorTitle'] = $account['fullName'] ?? '';
                    $item['creatorImage'] = $account['image'] ?? '';
                }
                $return['items'][$key] = $item;
            }
        }
    }
}
?>