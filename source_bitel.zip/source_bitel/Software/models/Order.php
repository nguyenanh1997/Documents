<?php
namespace Software;
class Order extends \CMS\Listing {
	static $type = 'Order';
    static $privileges = [
        'select' => 'Software.Group.admin',
        'selectAll' => 'Software.Group.admin',
        'selectList' => 'Software.Group.admin',
        'edit' => 'Software.Group.admin',
        'delete' => 'Software.Group.admin'
    ];
    static $options = [
        'fields' => '*',
        'orderBy' => 'createdTime DESC'
    ];
    private function checkCartInfo($cart,&$return){
        if(!empty($cart['items'])){
            return true;
        }else{
            $return['message'] = 'Bạn chưa lựa chọn sản phẩm cần mua';
        }
        return false;
    }
    protected function prepareCart(&$cart, &$return){
        $cart['day'] = (int)date('d',time());
        $cart['month'] = (int)date('m',time());
        $cart['year'] = (int)date('Y',time());
        $cart['week'] = (int)date('W',time());
        $cart['code'] = $this->makeOrderCode();
        $cart['groupId'] = CUser::$group['id'];
        $this->recalc($cart);
        if($this->preparePaymentInfo($cart, $return) !== false) {//Chuẩn bị thông tin thanh toán
            if($this->initInfo($cart, $return) === false) {//Khởi tạo các thông tin cần thiết
                return false;
            }
        }else{
            return false;
        }
        return true;
    }
    private function preparePaymentInfo(&$cart, &$return){
        return true;
    }
    /**
     * User: TheAnh
     * Usage:
    Privileges:shared
     */
    function insert($fields = []) {
        $return = [
            'status' => 'FAIL',
            'message' => lang('Đặt hàng không thành công'),
        ];
        $cart = cache('cart'.session());
        if(!empty($fields)) {
            $cart = array_merge($fields, $cart);
        }
        if(!empty($cart) and $this->checkCartInfo($cart, $return)) {//Kiểm tra thông tin giỏ hàng
            if($this->prepareCart($cart,$return)) {
                if ($id = Data(static::$type)->insert($cart)) {
                    $return['status'] = 'SUCCESS';
                    $return['message'] = "Đặt mua thành công";
                    $return['id'] = $cart['id'] = $id;
                    cache('cart'.session(), []);
                    $this->sendOrderEmail($cart);
                    $this->sendOrderNotification($cart);
                }
            }
        }
        return $return;
    }

    private function initInfo($cart, &$return){
        return true;
    }
    /**
     * User: hungnm
     * Usage: Tự động tạo ra mã đơn hàng
    Privileges:
    Rules:
     */
    private function makeOrderCode() {
        $newValue = Data('AutoCode')->autoCode(self::$type);
        return  portal()->id.'-'.str_pad(strval($newValue + 1), 9, '0', STR_PAD_LEFT);
    }
    /**
     * User: TheAnh
     * Usage: Tính toán số liệu
     * @param $fields
     * @return array|mixed
    Privileges:library
     */
    private function recalc(&$cart)
    {
        $totalItems = $totalAmount = 0;
        if(!empty($cart['items']) and is_array($cart['items'])) {
            foreach ($cart['items'] as $i => $item) {
                $quantity = (!empty($item['orderQuantity']) and $item['orderQuantity'] > 1) ? $item['orderQuantity'] : 1;
                $totalItems += $quantity;
                $cart['items'][$i]['totalAmount'] = $cart['items'][$i]['price']*$quantity;
                $totalAmount += $cart['items'][$i]['totalAmount'];
            }
        }
        $cart['totalItems'] = $totalItems;
        $cart['totalAmount'] = $totalAmount;

    }
	/**
	 * User: hungnm
	 * Usage: Gửi email tới những người liên quan đến đơn hàng
	 Privileges:
	 Rules:
	 - fields: Mảng dữ liệu thông tin đơn hàng. array()
	 */
	private function sendOrderEmail($fields = []) {
		if(!empty($fields)) {
			$receivers = [];
			$subject = 'Đơn đặt hàng mã số '.$fields['code'];
			if(!empty($fields['sellerEmail'])) {
				$receivers[] = $fields['sellerEmail'];
			}
			if(!empty(portal()->email)) {
				$receivers[] = portal()->email;
			}
			$emailTemplate = 'Ecommerce.EmailTemplate.orderSuccess';
			if($body = output()->get(CForm($emailTemplate)->parse($fields))
				and !empty($receivers)
				and !empty($subject)
			) {
				Common\lib\Email::send( [
					'subject' => $subject,
					'body' => $body,
					'recipients' => $receivers,
				]);
			}
		}
	}

	/**
	 * User: hungnm
	 * Usage: Gửi notification tới những người liên quan đến đơn hàng
	Privileges:
	Rules:
	- fields: Mảng dữ liệu thông tin đơn hàng. array()
	 */
	private function sendOrderNotification($fields = []) {
		

	//Empty function


	}
    protected function prepareFilters(&$filters)
    {
        parent::prepareFilters($filters);
        if(CUser::$group['type'] != 'Group.CMS'){
            $filters['groupId'] = CUser::$group['id'];
        }
    }
}

?>