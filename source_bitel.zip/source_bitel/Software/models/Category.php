<?php
namespace Software;
class Category extends \Service{

    function echoItems($items, &$content){
        if(!empty($items)){
            $content .= '<ul>';
            foreach ($items as $key => $item){
                $content .= '<li rel="'.$item['id'].'">';
                $content .= '<a href="'.url($item['rewriteURL']).'" title="'.$item['title'].'">'.$item['title'].'</a>';
                if(!empty($item['items'])){
                    $this->echoItems($item['items'],$content);
                }
                $content .= '</li>';
            }
            $content .= '</ul>';
        }
    }

    function siteMap(){
        $items = Data('Category')->fields('title,parentId,level,rewriteURL,image')->orderBy('sortOrder DESC')->itemsPerPage(10000)->selectAll(['site' => intval(portal()->id),'status' => '1']);
        foreach ($items as $key=>$item){
            if(!empty($item['parentId']) and empty($items[$item['parentId']])){
                $items[$key]['parentId'] = '';
            }
        }
        $items = \Common\lib\Tree::toArray($items);
        return [
            'items' => $items
        ];

    }
}