<?php

namespace Software;
class AccountLink extends \Social\AccountLink
{
    static $type = 'AccountLink';
    static $privileges = [
        'select' => 'Software.Account.selectAll',
        'selectAll' => 'Software.Account.selectAll',
        'selectList' => 'Software.Account.selectAll',
        'edit' => 'Software.Account.admin',
        'delete' => 'Software.Account.admin',
    ];
    protected function prepareFilters(&$filters){
        parent::prepareFilters($filters);
        if (CUser::$group['type'] != 'Group.CMS'){
            $filters['linkId'] = CUser::$group['id'];
        }
    }
    protected function prepareList(&$return){
        parent::prapareList($return);
        foreach ($return['items'] as $key => $item){
            if(!empty($item['linkId'])){
                $return['items'][$key]['title'] = Data('Group')->getTitle($item['linkId']);
            }
        }
    }

    /**
     * Usage: Tạo tài khoản cho đơn vị
     * Privileges: $privileges[edit],token
     * Log:
     */
    function createAccount($id, $fields, $options = []){
		if(!empty($id) and $account = Data('Account')->select($id) and (empty($account['groupId']) or $account['groupId'] != CUser::$group['id']))
		{
			return [
				'status' => 'FAIL',
				'message' => 'Không có quyền sửa tài khoản này',
			];
		}
		
        if($result = call('Software.Account.edit',['id'=>$id, 'fields'=>$fields,'options'=>$options])){
			return $result;
        }
        return '';
    }
}