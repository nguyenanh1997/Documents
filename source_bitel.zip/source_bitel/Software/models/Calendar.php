<?php
namespace Software;
class Calendar extends \CMS\CRUD{
    static $type = 'Calendar';
    static $privileges = [
        'select' => 'owner',
        'selectAll' => 'owner',
        'edit' => 'owner',
        'delete' => 'owner'
    ];
    /**
     * Privileges: shared
     */
    function getSendType(){
        $return = [
            [
                'id' => '1',
                'title' => 'Thông báo',
                'label' => 'Thông báo'
            ],
            [
                'id' => '2',
                'title' => 'Email',
                'label' => 'Email'
            ],
            [
                'id' => '3',
                'title' => 'SMS',
                'label' => 'SMS'
            ],
        ];
        return ['items' => $return];
    }
}