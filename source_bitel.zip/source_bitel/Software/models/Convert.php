<?php
namespace Software;
class Convert extends \Service{
    /**
     * Usage: Hàm chuyển số sang chữ
     * Privileges: shared
     */
    public function convertNumberToText($number){
        $hyphen = ' ';
        $conjunction = '  ';
        $separator = ' ';
        $negative = 'âm ';
        $decimal = ' phẩy ';
        $dictionary = [
            0 => 'Không',
            1 => 'Một',
            2 => 'Hai',
            3 => 'Ba',
            4 => 'Bốn',
            5 => 'Năm',
            6 => 'Sáu',
            7 => 'Bảy',
            8 => 'Tám',
            9 => 'Chín',
            10 => 'Mười',
            11 => 'Mười một',
            12 => 'Mười hai',
            13 => 'Mười ba',
            14 => 'Mười bốn',
            15 => 'Mười năm',
            16 => 'Mười sáu',
            17 => 'Mười bảy',
            18 => 'Mười tám',
            19 => 'Mười chín',
            20 => 'Hai mươi',
            30 => 'Ba mươi',
            40 => 'Bốn mươi',
            50 => 'Năm mươi',
            60 => 'Sáu mươi',
            70 => 'Bảy mươi',
            80 => 'Tám mươi',
            90 => 'Chín mươi',
            100 => 'trăm',
            1000 => 'ngàn',
            1000000 => 'triệu',
            1000000000 => 'tỷ',
            1000000000000 => 'nghìn tỷ',
            1000000000000000 => 'ngàn triệu triệu',
            1000000000000000000 => 'tỷ tỷ'
        ];

        if( !is_numeric( $number ) )
        {
            return false;
        }

        if( ($number >= 0 && (int)$number < 0) || (int)$number < 0 - PHP_INT_MAX )
        {
            trigger_error( 'convert_number_to_words only accepts numbers between -' . PHP_INT_MAX . ' and ' . PHP_INT_MAX, E_USER_WARNING );
            return false;
        }

        if( $number < 0 )
        {
            return $negative . $this->convertNumberToText( abs( $number ) );
        }

        $string = $fraction = null;

        if( strpos( $number, '.' ) !== false )
        {
            list( $number, $fraction ) = explode( '.', $number );
        }

        if($number < 21) {
            $string = $dictionary[$number];
        }elseif($number < 100) {
            $tens = ((int)($number / 10)) * 10;
            $units = $number % 10;
            $string = $dictionary[$tens];
            if ($units) {
                $string .= $hyphen . $dictionary[$units];
            }
        }elseif($number < 1000) {
            $hundreds = $number / 100;
            $remainder = $number % 100;
            $string = $dictionary[$hundreds] . ' ' . $dictionary[100];
            if ($remainder) {
                $string .= $conjunction . $this->convertNumberToText($remainder);
            }
        }else {
            $baseUnit = pow(1000, floor(log($number, 1000)));
            $numBaseUnits = (int)($number / $baseUnit);
            $remainder = $number % $baseUnit;
            $string = $this->convertNumberToText($numBaseUnits) . ' ' . $dictionary[$baseUnit];
            if ($remainder) {
                $string .= $remainder < 100 ? $conjunction : $separator;
                $string .= $this->convertNumberToText($remainder);
            }
        }

        if( null !== $fraction && is_numeric( $fraction ) )
        {
            $string .= $decimal;
            $words = [ ];
            foreach( str_split((string) $fraction) as $number )
            {
                $words[] = $dictionary[$number];
            }
            $string .= implode( ' ', $words );
        }
        return ucfirst(strtolower(str_replace('  ', ' ',$string)));
    }

    /**
     * @param $number
     * @return bool|string
     */
    public function convertNumberToPrice($number){
        $hyphen = ' ';
        $conjunction = '  ';
        $separator = ' ';
        $negative = 'âm ';
        $decimal = ' phẩy ';
        $dictionary = [
            1000 => 'ngàn',
            1000000 => 'triệu',
            1000000000 => 'tỷ',
            1000000000000 => '000 tỷ',
            1000000000000000 => 'ngàn triệu triệu',
            1000000000000000000 => 'tỷ tỷ'
        ];

        if( !is_numeric( $number ) )
        {
            return false;
        }

        if( ($number >= 0 && (int)$number < 0) || (int)$number < 0 - PHP_INT_MAX )
        {
            trigger_error( 'convert_number_to_words only accepts numbers between -' . PHP_INT_MAX . ' and ' . PHP_INT_MAX, E_USER_WARNING );
            return false;
        }

        if( $number < 0 )
        {
            return $negative . $this->convertNumberToText( abs( $number ) );
        }

        $string = $fraction = null;

        if( strpos( $number, '.' ) !== false )
        {
            list( $number, $fraction ) = explode( '.', $number );
        }

        if($number < 21) {
            $string = $dictionary[$number];
        }elseif($number < 100) {
            $tens = ((int)($number / 10)) * 10;
            $units = $number % 10;
            $string = $dictionary[$tens];
            if ($units) {
                $string .= $hyphen . $dictionary[$units];
            }
        }elseif($number < 1000) {
            $hundreds = $number / 100;
            $remainder = $number % 100;
            $string = $hundreds * 100;
            if ($remainder) {
                $string .= $conjunction . $this->convertNumberToText($remainder);
            }
        }else {
            $baseUnit = pow(1000, floor(log($number, 1000)));
            $numBaseUnits = (int)($number / $baseUnit);
            $remainder = $number % $baseUnit;
            $string = $numBaseUnits . ' ' . $dictionary[$baseUnit];
            if ($remainder) {
                $string .= $remainder < 100 ? $conjunction : $separator;
                $string .= $this->convertNumberToText($remainder);
            }
        }

        if( null !== $fraction && is_numeric( $fraction ) )
        {
            $string .= $decimal;
            $words = [ ];
            foreach( str_split((string) $fraction) as $number )
            {
                $words[] = $dictionary[$number];
            }
            $string .= implode( ' ', $words );
        }
        return ucfirst(strtolower(str_replace('  ', ' ',$string)));
    }
}