<?php
namespace Software\Group;
class DashboardIndex extends \CMS\Listing {
    static $type = 'CoreDecl.DashboardIndex';
    static $component = 'Software';
    static $options = [
        'itemsPerPage' => 20,
        'fields' => '*',
        'orderBy' => 'sortOrder DESC'
    ];
    static $privileges = [
        'select' => 'member',
        'selectAll' => 'member',
    ];
    /**
     * Privileges: $privileges[selectAll]
     * Component: $component
     */
    function countTotalItems($childType)
    {
        $return = 0;
        if(!empty($childType)){
            $return = Data($childType)->fields('id')->count([
                'site'=> intval(portal()->id),
                'projectId' => CUser::$group['id']
            ]);
        }
        return $return;
    }
    /**
     * Privileges: $privileges[selectAll]
     * Component: $component
     */
    function countTotalMember($childType = false)
    {
        $return = 0;
        $childType = !empty($childType) ? $childType : 'AccountLink';
        if(!empty($childType)){
            $return = Data($childType)->fields('id')->count([
                'site'=> intval(portal()->id),
                'linkId' => CUser::$group['id']
            ]);
        }
        return $return;
    }
}
?>