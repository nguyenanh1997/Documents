<?php

namespace Software\Group;
class Department extends \CMS\Listing
{
    static $type = 'Group';
    static $privileges = [
        'selectAll' => 'shared',
        'select' => 'shared',
    ];
    static $options = [
        'fields' => '-introduce,-timeSlots',
        'itemsPerPage' => 20,
        'orderBy' => 'sortOrder DESC'
    ];
    protected function prepareFilters(&$filters){
        parent::prepareFilters($filters);
        $filters['closures'] = CUser::$group['id'];
    }
    protected function prepareList(&$return){
        parent::prepareList($return);
        if(!empty($return['items'])){
            foreach ($return['items'] as $key => $item) {
				$return['items'][$key]['rating'] = round(((int)($item['totalStar'] ?? 0)) / ((isset($item['totalRating']) and $item['totalRating'] != 0) ? $item['totalRating'] : 1),1);
                if(!empty($item['id']) and ($item['id'] == CUser::$group['id'])){
                    unset($return['items'][$key]);
                    $return['totalItems']--;
                }
            }
        }
    }
}