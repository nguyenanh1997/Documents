<?php

namespace Software\Group;
class JobCalendar extends \CMS\Listing
{
    static $type = 'GroupDecl.JobCalendar';
    static $checkSite = true;
    static $privileges = [
        'selectAll' => 'shared',
        'selectList' => 'shared',
        'select' => 'shared',
    ];
    static $options = [
        'fields' => '*',
        'itemsPerPage' => 20,
        'orderBy' => 'sortOrder DESC',
    ];
    protected function prepareFilters(&$filters) {
        parent::prepareFilters($filters);
        $filters['groupId'] = CUser::$group['id'];

    }
    protected function prepareList(&$return)
    {
        parent::prepareList($return);
        if(!empty($return['items'])){
            foreach ($return['items'] as $key => $item){
                if(empty($return['items'][$item['specialistId']])){
                    $return['items'][$item['specialistId']] = [
                        'title' => Data('Decl')->getTitle($item['specialistId']),
                        'items' => []
                    ];
                }
                $return['items'][$item['specialistId']]['items'][] = $item;
                unset($return['items'][$key]);
            }
        }
    }
}