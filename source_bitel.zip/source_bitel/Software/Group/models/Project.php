<?php
namespace Software\Group;
class Project extends \CMS\Group {
    static $type = 'Group';
    static $component = 'Software';
    static $options = [
        'itemsPerPage' => 20,
        'fields' => '*',
        'orderBy' => 'sortOrder DESC'
    ];
    static $privileges = [
        'select' => 'shared',
        'selectAll' => 'member',
        'delete' => 'CMS.Group.admin',
        'edit' => 'CMS.Group.admin',
        'selectList' => 'CMS.Group.admin',
    ];
    protected function prepareFilters(&$filters){
        if(!empty($filters['startTime']) and is_string($filters['startTime'])) {
            if(strpos($filters['startTime'], '-') !== false) {
                list($startTime, $endTime) = array_map('trim', explode('-', $filters['startTime']));
            }
            else{
                $startTime = $endTime = $filters['startTime'];
            }

            if(!empty($startTime)){
                $startTime = CDateTime($startTime)->time;
            }
            if(!empty($endTime)){
                $endTime = CDateTime($endTime)->time + 24*3600 - 1;
            }
            if(!empty($endTime) && !empty($startTime)){
                $filters['startTime'] = [
                    '$gte' => intval($startTime),
                    '$lte' => intval($endTime)
                ];
            }
        }
        parent::prepareFilters($filters);
    }
    /**
     * Privileges: $privileges[select]
     * Component: $component
     */
    function select($id)
    {
        if (empty($id)) {
            $id = CUser::$group['id'];
        }
        if(!empty($id) and $item = Data(self::$type)->select($id)){
            if(!empty($item['privacy']) and ($item['privacy'] == '1')){
                if(user()->isOwner() or !empty(user()->accountLinks[$id])){
                    return $item;
                } else {
                    redirect('403');
                }
            }
            return $item;
        }
    }
}
?>