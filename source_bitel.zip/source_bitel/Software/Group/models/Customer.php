<?php
namespace Software\Group;
class Customer extends \CMS\Group {
    static $type = 'Group.Customer';
    static $component = 'Software';
    static $options = [
        'itemsPerPage' => 20,
        'fields' => '*',
        'orderBy' => 'sortOrder DESC'
    ];
    static $privileges = [
        'select' => 'member',
        'selectAll' => 'member',
        'delete' => 'Software.Project.Group.Customer.admin',
        'edit' => 'Software.Project.Group.Customer.admin',
        'selectList' => 'Software.Project.Group.Customer.admin',
    ];
}
?>