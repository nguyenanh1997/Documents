<?php
namespace Software\Group;
class Group extends \Software\Group
{
    /**
     * Privileges: $privileges[selectList]
     * Component: $component
     */
    function selectList($filters = false, $options = false){
        if(CUser::$group) {
            $filters = !empty($filters) ? $filters : [];
            $filters['closures'] = CUser::$group['id'];
            return parent::selectList($filters, $options);
        }
    }
    protected function prepareEdit(&$fields,&$oldItem,&$return)
    {
        if (!empty($fields['title'])) {
            $fields['title'] = quote(strip_tags(trim($fields['title'])));
            $fields['sortTitle'] = CVNCode::convertUtf8ToSort($fields['title']);
            return parent::prepareEdit($fields, $oldItem, $return);
        }
    }
}