<?php

namespace Software\Group;
class Transporter extends \CMS\Group
{
    static $type = 'Group';
    static $checkSite = true;
    static $privileges = [
        'selectAll' => 'Software.Group.selectAll',
        'select' => 'Software.Group.selectAll',
        'selectList' => 'shared',
        'edit' => 'Software.Group.admin',
        'delete' => 'Software.Group.admin',
    ];
    static $options = [
        'fields' => '*',
        'itemsPerPage' => 20,
        'orderBy' => 'sortOrder DESC'
    ];
    protected function prepareFilters(&$filters){
        parent::prepareFilters($filters);
        if (empty($filters['components'])){
            $filters['components'] = '5c62397276801b0eff147a35';
        }
    }
    protected function prepareEdit(&$fields, &$oldItem, &$return){
        if (empty($fields['components'])){
            $fields['components'] = '5c62397276801b0eff147a35';
        }
        return parent::prepareEdit($fields, $oldItem, $return);
    }
}