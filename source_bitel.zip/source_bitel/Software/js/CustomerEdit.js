Software.CustomerEdit = extend(Content.Form, {
	rules:{
		'fields[title]': {
			required:true,
			maxlength:100
		}		
	},
	messages: {},
	initEvents: function(){
		var that = this;
		SUPER.initEvents.call(this);
		VHV.load('Common.Input.Multiple', function(){
						
		});
	}
});