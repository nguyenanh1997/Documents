Software.TaskBoard = extend(Content.Listing, {
	filters:{},
	init: function(){
		var that = this;
		SUPER.init.call(this);
		setInterval(function(){
			that.reload();
		}, 300000);
		$('body').on('click', '.filterItem[data-action]', function(){
			var action = $(this).data('action');
			switch(action)
			{
				case 'filter':
					var filterType = $(this).data('filterType'),
						filterValue = $(this).data('filterValue');
					switch(filterType) {
						case 'creator':
							that.filters.creatorAccountId = filterValue;
							if($(this).hasClass('hasFilter')){
								that.filters.creatorAccountId = '';
								$(this).parents('.ModuleWrapper:first').find('.filterItem[data-action]').removeClass('hasFilter');
							} else {
								$(this).parents('.ModuleWrapper:first').find('.filterItem[data-action]').removeClass('hasFilter');
								$(this).addClass('hasFilter');
							}
							break;
						case 'isFeature':
							break;
						default: break;
					}
					that.reload();
					break;
				default: break;
			}
		});
	},
	initEvents: function(){
		var that = this;
		SUPER.initEvents.call(this);
			
		VHV.load('3rdparty/jQuery/jquery.simplyscroll/jquery.simplyscroll.css');
		VHV.load('3rdparty/jQuery/jquery.simplyscroll/jquery.simplyscroll.js',function(){
			if($('.taskItem').length > 10)
			{
				$('.scrollContainer'+that.id).simplyScroll({
					customClass: 'vert-mainList',
					autoMode: 'loop',			
					frameRate: 24,
					speed: 1,
					orientation: 'vertical'
				});
			}
		});	
		$(window).resize(function(){
			var mainHeight = $('.mainBoard').outerHeight(),
			 	sideBarTop = $('.mainBoard .sideBarTop').outerHeight(),
				cmsHeader = $('.cms-header-wrapper').outerHeight(),
				listHeader = $('.mainList-header').outerHeight(),
				cardNotice = $('#module'+that.id+' .card-notice').outerHeight();
			$('#module'+that.id+' .mainSidebar .list-assign-user').css({
				'height': $(window).height() - sideBarTop - $('#module'+that.id+' .task-sidebar-header').outerHeight() - (cmsHeader?cmsHeader:0) - 52
			});
			setTimeout(function(){
				$('.mainList .simply-scroll-clip').css({
					'height': $(window).height() - (listHeader?listHeader:0) - (cardNotice?cardNotice:0)
				});	
			},1000);
		});
	}
});