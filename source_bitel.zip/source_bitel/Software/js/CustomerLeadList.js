Software.CustomerLeadList = extend(Content.Listing, {
	filters:{},
	initEvents: function(){
		var that = this;
		SUPER.initEvents.call(this);
		if(this.parent)
		{
			this.parent.setBoxControl();
		}
		this.$('table .btn-group .dropdown-menu').each(function(){
			var li = $('a:not([style])', this);
			if(li.length)
			{
				$(this).parent().before('<br/>');
				$(this).parent().before($(li[0]).clone());
			}
		});
	}
});