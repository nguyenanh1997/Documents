<?php
namespace Software\Notification;
class Dashboard extends \CMS\CRUD{
    /**
     * Usage: Chỉ số tổng tiền nạp
     * Privileges: shared
     */
    function getNotificationTotal(){
        $filters = [
            'site' => intval(portal()->id),
        ];
        return [
            'totalCount' => Data('Message')->count($filters)
        ];
    }
    /**
     * Usage: Chỉ số thông báo đơn vị
     * Privileges: shared
     */
    function getUnitTotal(){
        $filters = [
            'site' => intval(portal()->id),
        ];
        return [
            'totalCount' => Data('Group')->count($filters)
        ];
    }
    /**
     * Usage: Chỉ số tổng tiền nạp
     * Privileges: shared
     */
    function getMoneylTotal(){
        $total = Data('Pocket')->aggregate([
            ['$match' => ['site' => (int) portal()->id]],
            ['$group' => ['_id' => null, 'total' => ['$sum' => '$totalCharge']]],
        ]);
        $total = current($total);
        return [
            'totalCount' => !empty($total['total']) ? $total['total'] : 0
        ];
    }
}