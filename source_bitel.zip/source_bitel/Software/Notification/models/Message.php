<?php

namespace Software\Notification;
class Message extends \Software\CRM\Marketing\Notification\Message
{
    static $privileges = [
        'select' => 'Software.Notification.Message.view',
        'selectAll' => 'Software.Notification.Message.view',
        'edit' => 'Software.Notification.Message.add',
    ];

    protected function prepareInsert(&$fields, $item, &$return)
    {
        if (!empty($item['notiType'])) {
            if ($item['notiType'] == 'sms' and !empty($item['listPhone']) and !empty($item['brandname'])) {
                if ($brandName = Data('GroupDecl.BrandName')->select($item['brandname'])) {
                    $fields['price'] = $brandName['price'];
                }
            } elseif ($item['notiType'] == 'email') {
                $fields['price'] = portal()->priceSendMail;
            }
        }

        if ($pocket = Data('Pocket')->select(['site' => intval(portal()->id), 'groupId' => $item['groupId']])) {
            if (!empty($item['listGroup'])) {
                $numberContact = 0;
                foreach ($item['listGroup'] as $groupId) {
                    $numberContact += Data('Contact')->count(['site' => intval(portal()->id), 'groupIds' => $groupId]);
                }
                if ($numberContact > 0 and !empty($pocket['balance']) AND intval($pocket['balance']) < intval($numberContact * intval($fields['price']))) {
                    $return['message'] = 'Tài khoản cần có tối thiểu ' . intval($numberContact * intval($fields['price'])) . ' VNĐ để thực hiện gửi thông báo này';
                    $return['status'] = 'FAIL';
                    return false;
                }
            }
        } else {
            $return['message'] = 'Tài khoản chưa nạp tiền, vui lòng nạp tiền để gửi thông báo';
            $return['status'] = 'FAIL';
            return false;
        }
        return parent::prepareInsert($fields, $item, $return);
    }

    protected function prepareSchedule(&$fields, $item, &$return)
    {
        if (!empty($item['notiType'])) {
            if ($item['notiType'] == 'sms' and !empty($item['listPhone']) and !empty($item['brandname'])) {
                if ($brandName = Data('GroupDecl.BrandName')->select($item['brandname'])) {
                    $fields['price'] = $brandName['price'];
                }
            } elseif ($item['notiType'] == 'email') {
                $fields['price'] = portal()->priceSendMail;
            }
        }
        return parent::prepareSchedule($fields, $item, $return);
    }

    protected function prepareSend($message = false, $contact = false, $options = [])
    {
        if (!empty($message) and !empty($message['notiType'])) {
            if ($message['notiType'] == 'email') {
                call('Software.Notification.Pocket.increment', ['groupId' => $message['groupId'], 'balance' => -intval(portal()->priceSendMail)]);
            }
        }
        return parent::prepareSend($message, $contact, $options);
    }

    public function sendSMSCallback($data, $options = [])
    {
        if (!empty($options['objectId']) and $message = Data('Message')->select($options['objectId'])) {
            if (!empty($message['notiType']) and $message['notiType'] == 'sms' and !empty($message['brandname']) and $brandName = Data('GroupDecl.BrandName')->select($message['brandname'])) {
                call('Software.Notification.Pocket.increment', ['groupId' => $message['groupId'], 'balance' => -intval($brandName['price'])]);
            }
        }
        parent::sendSMSCallback($data);
    }
}