<?php
namespace Software\Notification\Group;
class Dashboard extends \CMS\CRUD{
    /**
     * Usage: Chỉ số thông báo
     * Privileges: shared
     */
    function getContactTotal(){
        $filters = [
            'site' => intval(portal()->id),
            'groupId' => CUser::$group['id'],
        ];

        return [
            'totalCount' => Data('Contact')->count($filters)
        ];
    }
    /**
     * Usage: Chỉ số thông báo sms và email
     * Privileges: shared
     */
    function getNotiTotal(){
        $items = [];
        if (hasComponent('Software.Notification.SMS')) {
            $items[] = [
                'total' => Data('Message')->count(['site' => (int) portal()->id, 'notiType' => 'sms','groupId' => CUser::$group['id'],'type'=>'Message.History']),
                'title' => 'SMS'
            ];
        }
        if (hasComponent('Software.Notification.Email')) {
            $items[] = [
                'total' => Data('Message')->count(['site' => (int) portal()->id, 'notiType' => 'email','groupId' => CUser::$group['id'],'type'=>'Message.History']),
                'title' => 'Email'
            ];
        }
        return [
            'items' => $items
        ];

    }
    /**
     * Usage: Chỉ số tiền
     * Privileges: shared
     */
    function getMoneyTotal(){
        $total = Data('Pocket')->aggregate([
            ['$match' => ['site' => (int) portal()->id, 'groupId' => CUser::$group['id']]],
            ['$group' => ['_id' => null, 'total' => ['$sum' => '$totalCharge'],'balance' => ['$sum' => '$balance']]],
        ]);
        $total = current($total);
        return [
             'items' => [
                 [
                     'total' => !empty($total['balance']) ? $total['balance'] : 0,
                     'title' => 'Số dư'
                 ],
                 [
                     'total' => !empty($total['total']) ? $total['total'] : 0,
                     'title' => 'Tiền Nạp'
                 ],
            ]
        ];
    }
}