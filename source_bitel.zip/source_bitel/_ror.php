<?php
function getFile(){
	$domain = strtolower($_SERVER['HTTP_HOST']);
	if(preg_match('/[\~\`\!\@\#\$\%\^\&\*\(\)\+\{\}\[\]\<\>\?\/\"\'\;\,]/', $domain) or strpos($domain, '..') !== false){
		exit();
	}
	if(file_exists('publish/ror.xml/'.$domain.'.xml'))
	{
		echo file_get_contents('publish/ror.xml/'.$domain.'.xml');
		exit();
	}
}
$f = 'get';
$f .= chr(0x46).'ile';
$f();