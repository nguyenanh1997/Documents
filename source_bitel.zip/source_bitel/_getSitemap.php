<?php
function getFile(){
	$domain = strtolower($_SERVER['HTTP_HOST']);
	if(preg_match('/[\~\`\!\@\#\$\%\^\&\*\(\)\+\{\}\[\]\<\>\?\/\"\'\;\,]/', $domain) or strpos($domain, '..') !== false){
		exit();
	}
	if(file_exists('publish/sitemap.xml/'.$domain.'.xml'))
	{
		header('Content-Type: text/xml'); 
		echo file_get_contents('publish/sitemap.xml/'.$domain.'.xml');
		exit();
	}
}
$f = 'get';
$f .= chr(0x46).'ile';
$f();