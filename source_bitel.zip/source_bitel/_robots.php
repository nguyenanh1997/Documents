<?php
function getFile(){
$domain = strtolower($_SERVER['HTTP_HOST']);
if(preg_match('/[\~\`\!\@\#\$\%\^\&\*\(\)\+\{\}\[\]\<\>\?\/\"\'\;\,]/', $domain) or strpos($domain, '..') !== false){
	exit();
}
if(strpos($domain, '..') === false and strpos($domain, '/') === false and file_exists('publish/robots.txt/'.$domain.'.txt'))
{
	echo file_get_contents('publish/robots.txt/'.$domain.'.txt');
	exit();
}
?>User-agent: *
Host: <?php echo $domain;?>

Disallow: /data/
Disallow: /lib/
Disallow: /packages/
Disallow: /portals/
Disallow: /pages/
Disallow: /1/
Disallow: /content/download/
<?php
}
$f = 'get';
$f .= chr(0x46).'ile';
$f();